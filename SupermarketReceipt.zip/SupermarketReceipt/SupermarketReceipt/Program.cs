﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Linq;

namespace SupermarketReceipt
{
    class Product
    {
        private string name { get; set; }
        private bool domestic { get; set; }
        private float price { get; set; }
        private float weight { get; set; }
        private string description { get; set; }

        public Product(string name, bool domestic, float price, string description, float weight = 0)
        {
            this.name = name;
            this.domestic = domestic;
            this.price = price;
            this.weight = weight;
            this.description = description;
        }

        public string getName()
        {
            return this.name;
        }
        public bool getDemostic()
        {
            return this.domestic;
        }
        public string getDescription()
        {
            return this.description;
        }
        public float getPrice()
        {
            return this.price;
        }
        public float getWeight()
        {
            return this.weight;
        }

        public override string ToString()
        {
            String formated_price = String.Format("{0:f1}", this.price);

            String output = "... " + this.name + "\n"
                + "    " + "Price: $" + formated_price + "\n"
                + "    ";

            String trunc_description = this.description.Substring(0, 10) + "...";

            output += trunc_description + "\n" + "    " + "Weight: ";
            if (this.weight > 0)
                output += this.weight;
            else
                output += "N\\A";

            return output;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string url = "https://interview-task-api.mca.dev/qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1";

            using (WebClient client = new WebClient())
            {
                string info = client.DownloadString(url);

                var products = JsonConvert.DeserializeObject<List<Product>>(info);

                List<Product> domestic = products.FindAll(p => p.getDemostic() == true);
                domestic.Sort((x, y) => x.getName().CompareTo(y.getName()));

                List<Product> imported = products.FindAll(p => p.getDemostic() == false);
                imported.Sort((x, y) => x.getName().CompareTo(y.getName()));

                Console.WriteLine(". Domestic");
                foreach(var d in domestic)
                {
                    Console.WriteLine(d.ToString());
                }

                Console.WriteLine(". Imported");
                foreach (var i in imported)
                {
                    Console.WriteLine(i.ToString());
                }

                var sum_domestic = domestic.Sum(product => product.getPrice());
                var sum_imported = imported.Sum(product => product.getPrice());

                String d_sum = String.Format("{0:f1}", sum_domestic);
                String i_sum = String.Format("{0:f1}", sum_imported);

                Console.WriteLine("Domestic cost: $" + d_sum);
                Console.WriteLine("Imported cost: $" + i_sum);
                Console.WriteLine("Domestic count: " + domestic.Count);
                Console.WriteLine("Imported count: " + imported.Count);
            }
        }
    }
}
